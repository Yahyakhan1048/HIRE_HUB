import mongoose from "mongoose";

const jobSchema = new mongoose.Schema(
  {
    jobTitle: { type: String },
    category: { type: String },
    country: { type: String },
    city: { type: String },
    location: { type: String },
    salary: { type: String },
    description: { type: String },
  },
  { timestamps: true }
);
export default mongoose.model("job", jobSchema);

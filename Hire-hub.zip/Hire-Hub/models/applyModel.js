import mongoose from "mongoose";

const applySchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: true,
    },
    email: {
      type: String,
      required: true,
      unique: true,
    },
    phone: {
      type: String,
      required: true,
    },
    address: {
      type: String,
      required: true,
    },
    pdf: {
      type: String,
    },
    jobDescription: {
      type: String,
      required: true,
    },
    userId: {
      type: mongoose.ObjectId, //getting user id
      ref: "Users", //   make a relationship with userModel
      required: true,
    },
  },
  { timestamps: true }
);

export default mongoose.model("application", applySchema);

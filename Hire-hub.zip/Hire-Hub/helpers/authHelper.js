// Contain two function
//    first one for hashing the password
//    Second one is used for and compared and decrypt the password

import bcrypt from "bcrypt";

// ========== hashing the password that getting password argument from authController ========
export const hashPassword = async (password) => {
  try {
    // saltRound it is the round to hash the password like 10 round it take to hash the password
    const saltRounds = 10;
    const hashedPassword = await bcrypt.hash(password, saltRounds);
    return hashedPassword;
  } catch (error) {
    console.log(error);
  }
};

// ====== Second Password =======
export const comparePassword = async (password, hashedPassword) => {
  return bcrypt.compare(password, hashedPassword);
};

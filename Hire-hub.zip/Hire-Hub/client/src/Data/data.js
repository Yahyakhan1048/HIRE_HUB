export const userMenu = [
  {
    name: "Home",
    path: "/",
    icon: "fa-solid fa-house",
  },
  {
    name: "All Jobs",
    path: "/user/jobs",
    icon: "fa-solid fa-list",
  },
  {
    name: "My Application",
    path: "/user/userApplication",
    icon: "fa-solid fa-user-doctor",
  },
];

// ======= admin menu =====
export const adminMenu = [
  {
    name: "Home",
    path: "/",
    icon: "fa-solid fa-house",
  },

  {
    name: "All Jobs",
    path: "/admin/all-job",
    icon: "fa-solid fa-user-doctor",
  },
  {
    name: "Applicant Application",
    path: "/admin/applicant",
    icon: "fa-solid fa-user",
  },
  {
    name: "Post Job",
    path: "/admin/postjob",
    icon: "fa-solid fa-book-open-reader",
  },
  {
    name: "View Your Jobs",
    path: "/admin/viewjob",
    icon: "fa-solid fa-address-book",
  },
];

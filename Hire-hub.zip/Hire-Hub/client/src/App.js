import React from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import HomePage from "./pages/HomePage";
import Login from "./pages/Login";
import Register from "./pages/Register";
import PublicRoute from "./components/PublicRoute";
import ProtectedRoute from "./components/ProtectedRoute";
import PostJob from "./pages/admin/PostJob";
import AllJob from "./pages/admin/AllJob";
import ViewJob from "./pages/admin/ViewJob";
import UpdateJob from "./pages/admin/UpdateJob";
import Jobs from "./pages/user/Jobs";
import JobDetails from "./pages/user/JobDetails";
import ApplyJob from "./pages/user/ApplyJob";
import UserApplication from "./pages/user/UserApplication";
import ApplicantApplication from "./pages/admin/ApplicantApplication";
import Detail from "./pages/admin/Detail";

const App = () => {
  return (
    <>
      <BrowserRouter>
        <Routes>
          <Route
            path="/"
            element={
              <ProtectedRoute>
                <HomePage />
              </ProtectedRoute>
            }
          />
          <Route
            path="/user/jobs"
            element={
              <ProtectedRoute>
                <Jobs />
              </ProtectedRoute>
            }
          />
          <Route
            path="/user/userApplication"
            element={
              <ProtectedRoute>
                <UserApplication />
              </ProtectedRoute>
            }
          />
          <Route
            path="/job-details/:id"
            element={
              <ProtectedRoute>
                <JobDetails />
              </ProtectedRoute>
            }
          />
          <Route
            path="/apply"
            element={
              <ProtectedRoute>
                <ApplyJob />
              </ProtectedRoute>
            }
          />
          <Route
            path="/admin/postjob"
            element={
              <ProtectedRoute>
                <PostJob />
              </ProtectedRoute>
            }
          />
          <Route
            path="/admin/all-job"
            element={
              <ProtectedRoute>
                <AllJob />
              </ProtectedRoute>
            }
          />
          <Route
            path="/admin/detail/:id"
            element={
              <ProtectedRoute>
                <Detail />
              </ProtectedRoute>
            }
          />
          <Route
            path="/admin/applicant"
            element={
              <ProtectedRoute>
                <ApplicantApplication />
              </ProtectedRoute>
            }
          />
          <Route
            path="/admin/viewjob"
            element={
              <ProtectedRoute>
                <ViewJob />
              </ProtectedRoute>
            }
          />
          <Route
            path="/update/:id"
            element={
              <ProtectedRoute>
                <UpdateJob />
              </ProtectedRoute>
            }
          />
          <Route
            path="/login"
            element={
              <PublicRoute>
                <Login />
              </PublicRoute>
            }
          />
          <Route
            path="/register"
            element={
              <PublicRoute>
                <Register />
              </PublicRoute>
            }
          />
        </Routes>
      </BrowserRouter>
    </>
  );
};

export default App;

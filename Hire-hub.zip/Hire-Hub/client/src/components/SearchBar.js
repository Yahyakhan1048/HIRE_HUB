import React, { useState } from "react";
import axios from "axios";

const SearchBar = () => {
  const [keyword, setKeyword] = useState("");
  const [results, setResults] = useState([]);

  const handleSearch = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.get(`/api/v1/job/search-job/${keyword}`, {
        headers: {
          Authorization: `Bearer ${localStorage.getItem("token")}`,
        },
      });
      setResults(response.data);
    } catch (error) {
      console.error(error);
    }
  };

  return (
    <div>
      <nav className="navbar bg-body-tertiary">
        <div className="container-fluid pt-1">
          <form className="d-flex" role="search">
            <input
              className="form-control me-3"
              style={{ width: "400px" }}
              type="search"
              placeholder="Search Job......."
              aria-label="Search"
              value={keyword}
              onChange={(e) => setKeyword(e.target.value)}
            />
            <button
              type="button"
              className="btn btn-outline-dark"
              onClick={handleSearch}
            >
              Search
            </button>
          </form>
        </div>
      </nav>
      {results.length > 0 && (
        <div>
          <h2>Search Results:</h2>
          <ul>
            {results.map((job) => (
              <div className="card ms-4" style={{ width: "18rem" }}>
                <div className="card-body">
                  <h3 className="card-title">{job.jobTitle}</h3>
                  <p className="card-text">{job.country}</p>
                  <button
                    to="/admin/all-job"
                    type="button"
                    className="btn btn-lg btn-info"
                  >
                    Details
                  </button>
                </div>
              </div>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
};

export default SearchBar;

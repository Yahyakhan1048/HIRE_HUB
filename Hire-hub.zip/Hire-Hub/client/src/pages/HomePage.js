import React, { useEffect } from "react";
import axios from "axios";
import Layout from "./../components/Layout";
import { message } from "antd";

const HomePage = () => {
  // login user data
  const getUserData = async () => {
    try {
      const res = await axios.post(
        "/api/v1/user/getUserData",
        {},
        {
          headers: {
            Authorization: "Bearer " + localStorage.getItem("token"),
          },
        }
      );
    } catch (error) {
      message.error("Something went wrog");
    }
  };

  useEffect(() => {
    getUserData();
  }, []);
  return (
    <Layout>
      <div
        id="carouselExampleDark"
        className="carousel carousel-dark slide"
        data-bs-ride="carousel"
      >
        <div className="carousel-indicators">
          <button
            type="button"
            data-bs-target="#carouselExampleDark"
            data-bs-slide-to={0}
            className="active"
            aria-current="true"
            aria-label="Slide 1"
          />
          <button
            type="button"
            data-bs-target="#carouselExampleDark"
            data-bs-slide-to={1}
            aria-label="Slide 2"
          />
          <button
            type="button"
            data-bs-target="#carouselExampleDark"
            data-bs-slide-to={2}
            aria-label="Slide 3"
          />
        </div>
        <div className="carousel-inner">
          <div className="carousel-item active" data-bs-interval={10000}>
            <img
              src="./images/job_1.jpg"
              className="d-block w-100"
              alt="..."
              style={{ height: "550px", objectFit: "cover" }}
            />
            <div
              className="carousel-caption d-none d-md-block"
              style={{ top: "60%", left: "60%" }}
            >
              <h1 style={{ fontSize: "2rem" }}>Unlock Your Potential</h1>
              <p style={{ fontSize: "1.2rem" }}>
                The perfect job is not a myth, it's a reality waiting to happen
              </p>
            </div>
          </div>
          <div className="carousel-item" data-bs-interval={2000}>
            <img
              src="./images/job_2.jpg"
              className="d-block w-100"
              alt="..."
              style={{ height: "600px", objectFit: "cover" }}
            />
            <div
              className="carousel-caption d-none d-md-block"
              style={{ top: "20%" }}
            >
              <h1 style={{ fontSize: "2rem" }}>Career Confidence</h1>
              <p style={{ fontSize: "1.2rem" }}>
                Your next opportunity is just around the corner, keep moving
                forward
              </p>
            </div>
          </div>
          <div className="carousel-item">
            <img
              src="./images/job.jpg"
              className="d-block w-100"
              alt="..."
              style={{ height: "600px", objectFit: "cover" }}
            />
            <div
              className="carousel-caption d-none d-md-block"
              style={{ top: "80%" }}
            >
              <h1 style={{ fontSize: "2rem" }}>Empowering Your Career</h1>
              <p style={{ fontSize: "1.2rem" }}>
                Don't watch life from the sidelines, participate and create your
                own success
              </p>
            </div>
          </div>
        </div>
        <button
          className="carousel-control-prev"
          type="button"
          data-bs-target="#carouselExampleDark"
          data-bs-slide="prev"
        >
          <span className="carousel-control-prev-icon" aria-hidden="true" />
          <span className="visually-hidden">Previous</span>
        </button>
        <button
          className="carousel-control-next"
          type="button"
          data-bs-target="#carouselExampleDark"
          data-bs-slide="next"
        >
          <span className="carousel-control-next-icon" aria-hidden="true" />
          <span className="visually-hidden">Next</span>
        </button>
      </div>
    </Layout>
  );
};

export default HomePage;

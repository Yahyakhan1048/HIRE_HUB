import React, { useState } from "react";
import Layout from "../../components/Layout";
import { useNavigate } from "react-router-dom";
import { message } from "antd";
import axios from "axios";
const ApplyJob = () => {
  const [name, setName] = useState();
  const [email, setEmail] = useState();
  const [phone, setPhone] = useState();
  const [address, setAddress] = useState();
  const [letter, setLetter] = useState();
  const [file, setFile] = useState();
  const navigate = useNavigate();
  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!name || !email || !phone || !address || !letter) {
      message.error("Please fill in all fields");
      return;
    }
    try {
      const applyData = new FormData();
      applyData.append("name", name);
      applyData.append("email", email);
      applyData.append("phone", phone);
      applyData.append("address", address);
      // Add the missing field
      applyData.append("jobDescription", letter);
      applyData.append("file", file);
      const userId = localStorage.getItem("userId");
      if (userId) {
        applyData.append("userId", userId);
      }

      // console.log("All Data", name, image, letter, address, phone, email);
      // const token = localStorage.getItem("token");
      const res = await axios.post(
        "/api/v1/application/upload-files",
        applyData,
        {
          // headers: {
          //   Authorization: `Bearer ${token}`,
          //   "Content-Type": "multipart/form-data",
          // },
          headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`,
          },
        }
      );
      console.log("result", res);

      if (res.data.success) {
        message.success(res.data.message);
        navigate("/user/jobs");
      } else {
        message.error(res.data.message);
      }
    } catch (error) {
      message.error("Something went wrong");
    }
  };
  return (
    <Layout>
      <div className="container mt-6 p-4">
        <h1 className="text-center">Apply for Job</h1>
        <div className="row justify-content-center">
          <div className="col-md-12 p-4">
            <form onSubmit={handleSubmit}>
              <div className="row p-4 m-3">
                <div className="col-md-4">
                  <label htmlFor="jobTitle" className="form-label">
                    Name
                  </label>
                  <input
                    type="text"
                    value={name}
                    className="form-control"
                    id="name"
                    onChange={(e) => setName(e.target.value)}
                    placeholder="Enter Your name"
                  />
                </div>
                <div className="col-md-4">
                  <label htmlFor="email" className="form-label">
                    Email
                  </label>
                  <input
                    type="email"
                    value={email}
                    className="form-control"
                    id="email"
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="Enter your Email"
                  />
                </div>
                <div className="col-md-4">
                  <label htmlFor="phone" className="form-label">
                    Phone number
                  </label>
                  <input
                    type="Number"
                    value={phone}
                    className="form-control"
                    id="phone"
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="Enter phone Number"
                  />
                </div>
                <div className="col-md-4">
                  <label htmlFor="address" className="form-label">
                    Address
                  </label>
                  <input
                    type="text"
                    value={address}
                    className="form-control"
                    onChange={(e) => setAddress(e.target.value)}
                    id="address"
                    placeholder="Enter your address"
                  />
                </div>
                <div className="col-md-4">
                  <label htmlFor="image" className="form-label">
                    Image (All Files)
                  </label>
                  <div className="custom-file">
                    <input
                      type="file"
                      className="custom-file-input"
                      id="pdf"
                      accept="application/pdf*"
                      onChange={(e) => setFile(e.target.files[0])}
                    />
                    <label className="custom-file-label" htmlFor="image">
                      Choose Image
                    </label>
                  </div>
                </div>
              </div>

              <div className="mb-3 p-4 m-3">
                <label htmlFor="jobDescription" className="form-label">
                  Cover Letter
                </label>
                <textarea
                  className="form-control"
                  id="jobDescription"
                  rows="3"
                  value={letter}
                  onChange={(e) => setLetter(e.target.value)}
                ></textarea>
              </div>
              <button type="submit" className="btn btn-primary w-30 ms-5">
                Submit Apply
              </button>
            </form>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default ApplyJob;

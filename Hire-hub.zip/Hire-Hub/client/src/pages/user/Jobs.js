import React, { useEffect, useState } from "react";
import Layout from "../../components/Layout";
import { Link } from "react-router-dom";
import { message } from "antd";
import axios from "axios";

const Jobs = () => {
  const [allJob, setAllJob] = useState([]);
  const getJob = async () => {
    try {
      const timestamp = new Date().getTime(); // Generate a unique timestamp
      const res = await axios.get(`/api/v1/job/get-job?t=${timestamp}`, {
        headers: {
          Authorization: `Bearer ${localStorage.getItem("token")}`,
        },
      });
      if (res.data.success) {
        setAllJob(res.data.allRoom);
      } else {
        message.error(res.data.message);
      }
    } catch (error) {
      message.error("Something went wrong");
    }
  };

  useEffect(() => {
    getJob();
  }, []);

  return (
    <Layout>
      <>
        <h1 className="text-center p-3">Available Job Positions</h1>
        <div className="row p-3">
          {allJob &&
            allJob.map((job, index) => (
              <div className="col-md-4 mb-4">
                <div className="card" style={{ width: "24rem" }}>
                  <div className="card-body">
                    <h2 className="card-title">{job.jobTitle}</h2>
                    <p className="card-text">{job.country}</p>
                    <Link to={`/job-details/${job._id}`}>
                      <button
                        type="button"
                        className="btn btn-lg btn-primary ms-1"
                      >
                        Job Details
                      </button>
                    </Link>
                  </div>
                </div>
              </div>
            ))}
        </div>
      </>
    </Layout>
  );
};

export default Jobs;

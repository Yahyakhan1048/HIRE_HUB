import React, { useEffect, useState } from "react";
import Layout from "../../components/Layout";
import { message } from "antd";
import { Link } from "react-router-dom";
import axios from "axios";

const ViewJob = () => {
  const [allJob, setAllJob] = useState([]);
  const getJob = async () => {
    try {
      const timestamp = new Date().getTime(); // Generate a unique timestamp
      const res = await axios.get(`/api/v1/job/get-job?t=${timestamp}`, {
        headers: {
          Authorization: `Bearer ${localStorage.getItem("token")}`,
        },
      });
      if (res.data.success) {
        setAllJob(res.data.data);
      } else {
        message.error(res.data.message);
      }
    } catch (error) {
      message.error("Something went wrong");
    }
  };
  // ===== id is receiving from below delete button ========
  const handleDelete = async (id) => {
    try {
      const res = await axios.delete(`/api/v1/job/delete-job/${id}`, {
        headers: {
          Authorization: `Bearer ${localStorage.getItem("token")}`,
        },
      });
      if (res.data.success) {
        message.success(res.data.message);
        getJob();
      } else {
        message.error(res.data.message);
      }
    } catch (error) {
      message.error("something went Wrong");
    }
  };

  useEffect(() => {
    getJob();
  }, []);

  return (
    <Layout>
      <>
        <h1 className="text-center p-3">My All Posted Job</h1>
        <div className="row p-3">
          {allJob &&
            allJob.map((job, index) => (
              <div className="col-md-4 mb-4">
                <div className="card" style={{ width: "24rem" }}>
                  <div className="card-body">
                    <h2 className="card-title">{job.jobTitle}</h2>
                    <p className="card-text">{job.country}</p>
                    <div>
                      <Link to={`/update/${job._id}`}>
                        <button
                          type="button"
                          className="btn btn-lg btn-primary ms-2"
                        >
                          Update
                        </button>
                      </Link>
                      <button
                        onClick={() => handleDelete(job._id)}
                        type="button"
                        className="btn btn-lg btn-danger ms-3"
                      >
                        Delete
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            ))}
        </div>
      </>
    </Layout>
  );
};

export default ViewJob;

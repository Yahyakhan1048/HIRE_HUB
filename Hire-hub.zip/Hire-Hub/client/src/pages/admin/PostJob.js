import React, { useState } from "react";
import Layout from "../../components/Layout";
import axios from "axios";
import { message } from "antd";

const PostJob = () => {
  const [jobTitle, setjobTitle] = useState();
  const [category, setCategory] = useState();
  const [country, setCountry] = useState();
  const [salary, setSalary] = useState();
  const [city, setCity] = useState();
  const [location, setLocation] = useState();
  const [description, setDescription] = useState();

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const res = await axios.post(
        "/api/v1/job/job-post",
        {
          jobTitle,
          category,
          salary,
          city,
          description,
          country,
          location,
        },
        {
          headers: {
            Authorization: "Bearer " + localStorage.getItem("token"),
          },
        }
      );
      if (res.data.success) {
        message.success(res.data.message);
        setjobTitle("");
        setCategory("");
        setCountry("");
        setCity("");
        setLocation("");
        setSalary("");
        setDescription("");
      } else {
        message.error(res.data.message);
      }
    } catch (error) {
      message.error("Something went wrong");
    }
  };

  return (
    <Layout>
      <div className="container mt-6 p-4">
        <div className="row justify-content-center">
          <div className="col-md-12 p-4">
            <form onSubmit={handleSubmit}>
              <div className="row p-4 m-3">
                <div className="col-md-4">
                  <label
                    htmlFor="jobTitle"
                    className="form-label pb-2"
                    style={{ fontSize: "18px" }}
                  >
                    Job Title
                  </label>
                  <input
                    type="text"
                    value={jobTitle}
                    className="form-control pb-2"
                    id="jobTitle"
                    onChange={(e) => setjobTitle(e.target.value)}
                    placeholder="Enter job title"
                  />
                </div>
                <div className="col-md-4">
                  <label
                    htmlFor="category"
                    className="form-label pb-2"
                    style={{ fontSize: "18px" }}
                  >
                    Category
                  </label>
                  <input
                    type="text"
                    value={category}
                    className="form-control pb-2"
                    id="jobTitle"
                    onChange={(e) => setCategory(e.target.value)}
                    placeholder="Enter your Category"
                  />
                </div>
                <div className="col-md-4">
                  <label
                    htmlFor="country"
                    className="form-label pb-2"
                    style={{ fontSize: "18px" }}
                  >
                    Country
                  </label>
                  <input
                    type="text"
                    value={country}
                    className="form-control pb-2"
                    id="country"
                    onChange={(e) => setCountry(e.target.value)}
                    placeholder="Enter country"
                  />
                </div>
                <div className="col-md-4">
                  <label
                    htmlFor="city"
                    className="form-label pb-2 pt-2"
                    style={{ fontSize: "18px" }}
                  >
                    City
                  </label>
                  <input
                    type="text"
                    value={city}
                    className="form-control pb-2"
                    onChange={(e) => setCity(e.target.value)}
                    id="city"
                    placeholder="Enter city"
                  />
                </div>
                <div className="col-md-4">
                  <label
                    htmlFor="location"
                    className="form-label pb-2 pt-2"
                    style={{ fontSize: "18px" }}
                  >
                    Location
                  </label>
                  <input
                    type="text"
                    value={location}
                    className="form-control pb-2"
                    onChange={(e) => setLocation(e.target.value)}
                    id="location"
                    placeholder="Enter location"
                  />
                </div>
                <div className="col-md-4">
                  <label
                    htmlFor="salary"
                    className="form-label pb-2 pt-2"
                    style={{ fontSize: "18px" }}
                  >
                    Salary
                  </label>
                  <input
                    type="text"
                    value={salary}
                    className="form-control pb-2"
                    onChange={(e) => setSalary(e.target.value)}
                    id="salary"
                    placeholder="Enter salary"
                  />
                </div>
              </div>
              <div className="mb-3 p-4 m-3">
                <label
                  htmlFor="jobDescription"
                  className="form-label pb-2"
                  style={{ fontSize: "18px" }}
                >
                  Job Description
                </label>
                <textarea
                  className="form-control pb-2"
                  id="jobDescription"
                  rows="3"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                ></textarea>
              </div>
              <button
                type="submit"
                className="btn btn-primary w-30 ms-5"
                style={{ fontSize: "18px" }}
              >
                Create Post
              </button>
            </form>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default PostJob;

import React, { useState, useEffect } from "react";
import Layout from "../../components/Layout";
import axios from "axios";
import { message } from "antd";
import { useNavigate, useParams } from "react-router-dom";
const UpdateJob = () => {
  const navigate = useNavigate();
  const { id } = useParams();
  console.log("Job Id", id);
  const [jobDetails, setJobDetails] = useState({
    _id: "",
    jobTitle: "",
    category: "",
    country: "",
    city: "",
    location: "",
    salary: "",
    description: "",
  });

  useEffect(() => {
    const fetchJobDetails = async () => {
      try {
        const res = await axios.get(`/api/v1/job/single-job/${id}`, {
          headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`,
          },
        });

        if (res.data.success) {
          setJobDetails(res.data.data);
        } else {
          message.error(res.data.message);
          navigate("/admin/all-job"); // Redirect if job not found
        }
      } catch (error) {
        message.error("Something went wrong");
      }
    };

    fetchJobDetails();
  }, [id, navigate]); // Re-fetch on job ID change

  const handleUpdate = async (e) => {
    e.preventDefault();
    try {
      const updatedJobDetails = { ...jobDetails };
      delete updatedJobDetails._id; // Remove _id from the object
      const res = await axios.put(
        `/api/v1/job/update-job/${id}`,
        updatedJobDetails,
        {
          headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`,
          },
        }
      );
      if (res.data.success) {
        message.success(res.data.message);
        navigate("/admin/all-job");
      } else {
        message.error(res.data.message);
      }
    } catch (error) {
      message.error("Something went wrong");
    }
  };

  const setJobTitle = (value) => {
    setJobDetails({ ...jobDetails, jobTitle: value });
  };

  const setCategory = (value) => {
    setJobDetails({ ...jobDetails, category: value });
  };

  const setCountry = (value) => {
    setJobDetails({ ...jobDetails, country: value });
  };

  const setCity = (value) => {
    setJobDetails({ ...jobDetails, city: value });
  };

  const setLocation = (value) => {
    setJobDetails({ ...jobDetails, location: value });
  };

  const setSalary = (value) => {
    setJobDetails({ ...jobDetails, salary: value });
  };

  const setDescription = (value) => {
    setJobDetails({ ...jobDetails, description: value });
  };

  return (
    <Layout>
      <div className="container mt-6 p-4">
        <div className="row justify-content-center">
          <h1 className="text-center">Update Jobs</h1>
          <div className="col-md-12 p-4">
            <form onSubmit={handleUpdate}>
              <div className="row p-4 m-3">
                <div className="col-md-4">
                  <label htmlFor="jobTitle" className="form-label">
                    Job Title
                  </label>
                  <input
                    type="text"
                    value={jobDetails.jobTitle}
                    className="form-control"
                    id="jobTitle"
                    onChange={(e) => setJobTitle(e.target.value)}
                    placeholder="Enter job title"
                  />
                </div>
                <div className="col-md-4">
                  <label htmlFor="category" className="form-label">
                    Category
                  </label>
                  <input
                    type="text"
                    value={jobDetails.category}
                    className="form-control"
                    id="jobTitle"
                    onChange={(e) => setCategory(e.target.value)}
                    placeholder="Enter your Category"
                  />
                </div>

                <div className="col-md-4">
                  <label htmlFor="country" className="form-label">
                    Country
                  </label>
                  <input
                    type="text"
                    value={jobDetails.country}
                    className="form-control"
                    id="country"
                    onChange={(e) => setCountry(e.target.value)}
                    placeholder="Enter country"
                  />
                </div>
                <div className="col-md-4">
                  <label htmlFor="city" className="form-label">
                    City
                  </label>
                  <input
                    type="text"
                    value={jobDetails.city}
                    className="form-control"
                    onChange={(e) => setCity(e.target.value)}
                    id="city"
                    placeholder="Enter city"
                  />
                </div>
                <div className="col-md-4">
                  <label htmlFor="location" className="form-label">
                    Location
                  </label>
                  <input
                    type="text"
                    value={jobDetails.location}
                    className="form-control"
                    onChange={(e) => setLocation(e.target.value)}
                    id="location"
                    placeholder="Enter location"
                  />
                </div>
                <div className="col-md-4">
                  <label htmlFor="salary" className="form-label">
                    Salary
                  </label>
                  <input
                    type="text"
                    value={jobDetails.salary}
                    className="form-control"
                    onChange={(e) => setSalary(e.target.value)}
                    id="salary"
                    placeholder="Enter salary"
                  />
                </div>
              </div>

              <div className="mb-3 p-4 m-3">
                <label htmlFor="jobDescription" className="form-label">
                  Job Description
                </label>
                <textarea
                  className="form-control"
                  id="jobDescription"
                  rows="3"
                  value={jobDetails.description}
                  onChange={(e) => setDescription(e.target.value)}
                ></textarea>
              </div>
              <button type="submit" className="btn btn-primary w-30 ms-5">
                Update Post
              </button>
            </form>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default UpdateJob;

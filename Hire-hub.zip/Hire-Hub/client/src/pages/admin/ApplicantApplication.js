import React, { useState, useEffect } from "react";
import Layout from "../../components/Layout";
import axios from "axios";
import { message } from "antd";
import { useNavigate } from "react-router-dom";
const ApplicantApplication = () => {
  const [applications, setApplications] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchApplications = async () => {
      try {
        const res = await axios.get("/api/v1/application/get-applicant", {
          headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`,
          },
        });
        setApplications(res.data.data);
      } catch (error) {
        console.error(error);
      }
    };
    fetchApplications();
  }, []);
  // ================ Delete application ==========
  const handleDelete = async (id) => {
    try {
      const res = await axios.delete(
        `/api/v1/application/delete-applicant/${id}`,
        {
          headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`,
          },
        }
      );
      if (res.data.success) {
        message.success(res.data.message);
        navigate("/admin/applicant");
      } else {
        message.error(res.data.message);
      }
    } catch (error) {
      message.error("something went Wrong");
    }
  };
  //========== Show cv ========
  const showCv = (pdf) => {
    window.open(`http://localhost:8080/files/${pdf}`, "_blank", "noreferrer");
  };
  return (
    <Layout>
      <div>
        <h1 className="text-center m-3 p-3 ">Applicants Applications</h1>
        <table class="table">
          <thead>
            <tr className="p-4 m-3 ms-2 text-center">
              <th scope="col" className="fs-3 fw-bold">
                Details
              </th>
              <th scope="col" className="fs-3 fw-bold">
                PDF
              </th>
              <th scope="col" className="fs-3 fw-bold">
                Action
              </th>
            </tr>
          </thead>
          <tbody>
            {applications.map((application) => (
              <tr key={application._id}>
                <td class="p-4 m-3 align-item-center">
                  <h2>{application.name}</h2>
                  <p>{application.email}</p>
                  <p>{application.phone}</p>
                  <p>{application.address}</p>
                  <p>{application.jobDescription}</p>
                </td>
                <td class="p-4 m-3 text-center align-middle">
                  <button
                    type="button"
                    class="btn btn-primary btn-lg"
                    onClick={() => showCv(application.pdf)}
                  >
                    Open Cv
                  </button>
                </td>
                <td class="p-4 m-3 text-center align-middle">
                  <button
                    type="button"
                    to="/admin/viewjob"
                    onClick={() => handleDelete(application._id)}
                    class="btn btn-danger btn-lg"
                  >
                    Delete Application
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </Layout>
  );
};

export default ApplicantApplication;

import React, { useEffect, useState } from "react";
import Layout from "../../components/Layout";
import { message } from "antd";
import { useParams } from "react-router-dom";
import axios from "axios";
const Detail = () => {
  const [details, setDetails] = useState();
  const { id } = useParams();
  console.log("Job Id", id);
  const getDetails = async () => {
    try {
      const res = await axios.get(`/api/v1/job/single-job/${id}`, {
        headers: {
          Authorization: `Bearer ${localStorage.getItem("token")}`,
        },
      });

      if (res.data.success) {
        setDetails(res.data.data);
      } else {
        message.error(res.data.message);
      }
    } catch (error) {
      message.error("Something went wrong");
    }
  };
  useEffect(() => {
    getDetails();
  }, [id]);
  return (
    <Layout>
      <div className="container mt-4">
        <h1 className="text-center p-3">Job Specification</h1>
        {details && ( // Check if details exist before rendering
          <div className="card p-4 border-0">
            <div className="card-body">
              <p className="card-title">
                <span className="fw-bold">Title:</span> {details.jobTitle}
              </p>
              <p className="card-text">
                <span className="fw-bold">Category:</span> {details.category}
              </p>
              <p className="card-text">
                <span className="fw-bold">Country:</span> {details.country}
              </p>
              <p className="card-text">
                <span className="fw-bold">City:</span> {details.city}
              </p>
              <p className="card-text">
                <span className="fw-bold">Location:</span> {details.location}
              </p>
              <p className="card-text">
                <span className="fw-bold">Salary:</span> {details.salary}
              </p>
              <p className="card-text">
                <span className="fw-bold">Description:</span>{" "}
                {details.description}
              </p>
              <p className="card-text">
                <span className="fw-bold">Posted On:</span> {details.createdAt}
              </p>
            </div>
          </div>
        )}
      </div>
    </Layout>
  );
};

export default Detail;

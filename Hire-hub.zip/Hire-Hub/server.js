import express from "express";

import morgan from "morgan"; // this package tell us which request has been hit
import connectDB from "./config/db.js";
import userRoute from "./routes/userRoute.js";
import jobRoute from "./routes/jobRoute.js";
import applictionRoute from "./routes/applicationRoute.js";
import dotenv from "dotenv";
import colors from "colors";
import cors from "cors";

// Configure env

dotenv.config();

// rest object
const app = express();
// Connect databae

connectDB();
// middleware
app.use(cors());
app.use(express.json());
app.use(morgan("dev"));
app.use("/files", express.static("files")); // --------- it will make this folder static every one can access to them
// routes

app.use("/api/v1/user", userRoute);
app.use("/api/v1/job", jobRoute);
app.use("/api/v1/application", applictionRoute);

app.get("/", (req, res) => {
  res.send("<h1>Welcome Job seeking website</h1>");
});

// server listening port

const PORT = process.env.PORT || 8080;

app.listen(PORT, () => {
  console.log(
    `Server is running on ${process.env.DEV_MODE} on port ${PORT}`.bgGreen.white
      .bold
  );
});

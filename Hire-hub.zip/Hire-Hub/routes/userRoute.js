import exporess from "express";
import {
  loginController,
  registerController,
  authController,
} from "../controllers/userControler.js";
import authMiddleware from "../middlewares/authMiddleware.js";
const router = exporess.Router();

// =========== routers ==========
// ------ post // register ----------
router.post("/register", registerController);
// ------ post // login ---------
router.post("/login", loginController);

//Auth || POST
router.post("/getUserData", authMiddleware, authController);
export default router;

// export default router;
import express from "express";
import authMiddleware from "../middlewares/authMiddleware.js";
import multer from "multer";
import {
  applyController,
  deleteApplicantApplication,
  deleteUserApplication,
  getUApplicantApplication,
  getUserApplication,
} from "../controllers/applyController.js";

const router = express.Router();

const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, "./files");
  },
  filename: function (req, file, cb) {
    const uniqueSuffix = Date.now();
    cb(null, uniqueSuffix + file.originalname);
  },
});

const upload = multer({ storage: storage });
//========== posting application of user on user side ============
router.post(
  "/upload-files",
  authMiddleware,
  upload.single("file"),
  applyController
);

//======= Getting application of user on userside ==========

router.get("/get-application", authMiddleware, getUserApplication);

//========= Delete user Application
router.delete("/delete-application/:id", authMiddleware, deleteUserApplication);

//================= Getting application of user on admin side ===========
router.get("/get-applicant", authMiddleware, getUApplicantApplication);

//========= Delete user Application ===========================
router.delete(
  "/delete-applicant/:id",
  authMiddleware,
  deleteApplicantApplication
);
export default router;

import express from "express";
import authMiddleware from "../middlewares/authMiddleware.js";
import {
  deleteJobController,
  getJobController,
  jobController,
  searchJobController,
  singleJobController,
  updateJobController,
} from "../controllers/jobController.js";
const router = express.Router();

// routes
// ------- posting all job --------
router.post("/job-post", authMiddleware, jobController);

// ----------- Getting a job  --------------
router.get("/get-job", authMiddleware, getJobController);

//============= search job through keyword =============

router.get("/search-job/:keyword", authMiddleware, searchJobController);

//------- Update job ----------
router.put("/update-job/:id", authMiddleware, updateJobController);
//--------- Fetching single job details ---------
router.get("/single-job/:id", authMiddleware, singleJobController);
// -------- Delete Job -----------
router.delete("/delete-job/:id", authMiddleware, deleteJobController);

export default router;

import JWT from "jsonwebtoken";

export default async (req, res, next) => {
  try {
    //======== New code add for image ===
    const authorizationHeader = req.headers["authorization"];
    if (!authorizationHeader || !authorizationHeader.startsWith("Bearer ")) {
      return res.status(401).send({ message: "Auth failed", success: false });
    }

    // =========end ==========
    // get token they are at 1 index
    const token = req.headers["authorization"].split("Bearer ")[1];
    JWT.verify(token, process.env.JWT_SECRET, (err, decode) => {
      if (err) {
        return res
          .status(200)
          .send({ message: "Authorization failed", success: false });
      } else {
        req.body.userId = decode._id;
        next();
      }
    });
  } catch (error) {
    console.log(error);
    res.status(401).send({ message: "Auth failed", success: false });
  }
};

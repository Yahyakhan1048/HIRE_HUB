import applyModel from "../models/applyModel.js";

//=========== Submitting application for the job ============
export const applyController = async (req, res) => {
  try {
    const { name, email, phone, address, jobDescription, userId } = req.body;
    const fileName = req.file.filename;

    // Check if the user has already applied for the job
    const existingApplication = await applyModel.findOne({
      name,
      email,
    });
    if (existingApplication) {
      return res.status(400).send({
        success: false,
        message: "You have already applied for this job",
      });
    }

    const apply = new applyModel({
      name,
      email,
      phone,
      address,
      jobDescription,
      pdf: fileName,
      userId,
    });
    await apply.save();
    res.status(200).send({
      success: true,
      message: "Form uploaded successfully",
    });
  } catch (error) {
    res.status(400).send({
      success: false,
      message: "Error in form uploading",
      error,
    });
  }
};

//========== Getting single user application data on user side ============

export const getUserApplication = async (req, res) => {
  try {
    const { userId } = req.query; // Retrieve userId from query parameters
    const applications = await applyModel.find({ userId });
    res.status(200).send({ success: true, data: applications });
  } catch (error) {
    res
      .status(400)
      .send({ success: false, message: "Error fetching applications", error });
  }
};

/// ========== Delete User Application on user side ===============

export const deleteUserApplication = async (req, res) => {
  try {
    const { id } = req.params;
    const application = await applyModel.findById(id);
    if (!application) {
      res
        .status(404)
        .send({ success: false, message: "Application not found" });
    } else {
      await applyModel.findByIdAndDelete(id);
      res
        .status(200)
        .send({ success: true, message: "Application Deleted Successfully" });
    }
  } catch (error) {
    console.log(error);
    res.status(500).send({
      success: false,
      message: "Error while deleting application",
      error,
    });
  }
};

// ===================== Getting applicant application on admin side ======================

export const getUApplicantApplication = async (req, res) => {
  try {
    const applications = await applyModel.find({});
    res.status(200).send({ success: true, data: applications });
  } catch (error) {
    res
      .status(400)
      .send({ success: false, message: "Error fetching applications", error });
  }
};

//====================== Delete Applicatn application on admin side ============
export const deleteApplicantApplication = async (req, res) => {
  try {
    const { id } = req.params;
    const application = await applyModel.findById(id);
    if (!application) {
      res
        .status(404)
        .send({ success: false, message: "Application not found" });
    } else {
      await applyModel.findByIdAndDelete(id);
      res
        .status(200)
        .send({ success: true, message: "Application Deleted Successfully" });
    }
  } catch (error) {
    console.log(error);
    res.status(500).send({
      success: false,
      message: "Error while deleting application",
      error,
    });
  }
};

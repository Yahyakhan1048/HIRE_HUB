import jobModel from "../models/jobModel.js";

export const jobController = async (req, res) => {
  try {
    const { jobTitle, category, salary, city, description, country, location } =
      req.body;
    if (!jobTitle) {
      return res.send({ message: "Job Title is required" });
    }
    if (!category) {
      return res.send({ message: "Category is required" });
    }
    if (!salary) {
      return res.send({ message: "Salary is required" });
    }
    if (!city) {
      return res.send({ message: "City is required" });
    }
    if (!description) {
      return res.send({ message: "Description is required" });
    }
    if (!country) {
      return res.send({ message: "Country is required" });
    }
    if (!location) {
      return res.send({ message: "Location is required" });
    }
    const newJob = await new jobModel({
      jobTitle,
      category,
      salary,
      city,
      description,
      country,
      location,
    }).save();
    return res.status(200).send({
      success: true,
      message: "job post successfully",
      data: newJob,
    });
  } catch (error) {
    console.log(error);
    res.status(500).send({
      success: false,
      message: "Error in job creating",
      error,
    });
  }
};
// -------------- Getting all job --------------
export const getJobController = async (req, res) => {
  try {
    const alljobs = await jobModel.find({});
    if (alljobs.length === 0) {
      return res
        .status(200)
        .send({ success: true, message: "No jobs found", data: [] });
    }
    res.status(200).send({
      success: true,
      message: "Fetch jobs successfully",
      data: alljobs,
    });
  } catch (error) {
    console.log(error);
    res.status(500).send({
      success: false,
      message: "Error while fetching jobs",
      error,
    });
  }
};

// ------------ single job details----------
export const singleJobController = async (req, res) => {
  try {
    const { id } = req.params; // Get the job ID from URL parameter

    // Check if job ID is provided
    if (!id) {
      return res.status(400).send({
        success: false,
        message: "Job ID is required",
      });
    }

    // Find the job by ID with authorization (optional)
    const job = await jobModel.findById(id);

    // Check if job exists
    if (!job) {
      return res.status(404).send({
        success: false,
        message: "Job not found",
      });
    }

    // Return the job details
    return res.status(200).send({
      success: true,
      message: "Fetch single job details successfully",
      data: job,
    });
  } catch (error) {
    console.error(error);
    return res.status(500).send({
      success: false,
      message: "Error fetching job details",
    });
  }
};

// ---------------------- Update job  -----------

export const updateJobController = async (req, res) => {
  try {
    const { id } = req.params;
    const updatedJobDetails = req.body;
    const job = await jobModel.findByIdAndUpdate(id, updatedJobDetails, {
      new: true,
    });
    if (!job) {
      return res.status(404).send({ success: false, message: "Job not found" });
    }
    res.send({ success: true, message: "Job updated successfully" });
  } catch (error) {
    console.error(error);
    return res.status(500).send({
      success: false,
      message: "Error fetching job details",
    });
  }
};
//------------ Deleting job -----------

export const deleteJobController = async (req, res) => {
  try {
    const { id } = req.params;
    const job = await jobModel.findById(id);
    if (!job) {
      res.status(404).send({ success: false, message: "Job not found" });
    } else {
      await jobModel.findByIdAndDelete(id);
      res
        .status(200)
        .send({ success: true, message: "Job Deleted Successfully" });
    }
  } catch (error) {
    console.log(error);
    res.status(500).send({
      success: false,
      message: "Error while deleting Job",
      error,
    });
  }
};

//====================== Search job through keyword ===========

export const searchJobController = async (req, res) => {
  try {
    const { keyword } = req.params; // extract keyword
    const resutls = await jobModel.find({
      // Exracting product through keyword that may be match with name or description
      $or: [
        { jobTitle: { $regex: keyword, $options: "i" } }, // i mean remove the case sensitive
        { country: { $regex: keyword, $options: "i" } },
      ],
    });
    res.json(resutls);
  } catch (error) {
    console.log(error);
    res.status(400).send({
      success: false,
      message: "Error in Search Product",
      error,
    });
  }
};
